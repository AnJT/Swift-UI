# Location Based Service App with AR

This is a mini project based on location based service with AR. Google map SDK has been used for map display purpose. The data for nearby places have been received using Google places API. Also, MKDirections from Apple Inc. has been used for plotting direction from source to destination.

