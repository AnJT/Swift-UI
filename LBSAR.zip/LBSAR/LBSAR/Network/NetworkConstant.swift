//
//  NetworkConstant.swift
//  LBSAR
//
//  Created by ajt on 2021/12/16.
//

import Foundation

extension Constants {
    struct URL {
        static let baseUrl = "https://maps.googleapis.com/maps/api/place/"
    }
    
    struct APIKey {
        static let googleApiKey = "AIzaSyA-5_9qVLe9o2jSWWlFaIb6bcj57AksKtc"
    }
}
