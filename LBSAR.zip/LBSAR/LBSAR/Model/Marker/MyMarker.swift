//
//  MyMarker.swift
//  LBSAR
//
//  Created by ajt on 2021/12/16.
//

import UIKit
import GoogleMaps

class MyMarker: GMSMarker {
    var place: Place?
}
