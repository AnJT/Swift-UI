//
//  HomeItem.swift
//  LBSAR
//
//  Created by ajt on 2021/12/16.
//

import UIKit

class HomeItem: NSObject {
    var itemTitle = ""
    var key = ""
}
