//
//  Constant.swift
//  LBSAR
//
//  Created by ajt on 2021/12/16.
//

import Foundation

struct Constants {
    
    struct Preferences {
        static let collectionViewSectionInset = 10
        static let collectionViewMinmCellSpacing = 10
        static let mapRadius = 9000
    }
}
